export const stockSymbols = [
    "AAPL", "GOOGL", "MSFT", "AMZN", "TSLA","NVDA","META","NKE","NFLX","V",
    // เพิ่มเติมได้
  ];
  