export const cryptoSymbols = [
    "BTCUSD", "ETHUSD", "BNBUSD", "XRPUSD", "SOLUSD","DOGEUSD","LINKUSDT","TONUSDT","ADAUSDT","DOTUSDT",
    // เพิ่มเติมได้
  ];
  