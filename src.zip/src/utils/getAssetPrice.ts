// utils/getAssetPrice.ts

export const getAssetPrice = async (symbol: string, category: string): Promise<number> => {
    let price = 0;
  
    if (category === "Crypto") {
      // ใช้ WebSocket ดึงราคาจาก Binance
      price = await fetchBinancePrice(symbol);
    } else if (category === "Stock") {
      // ดึงราคาจาก Yahoo API
      price = await fetchYahooPrice(symbol);
    }
  
    return price;
  };
  
  // ฟังก์ชันที่ใช้ WebSocket เพื่อดึงราคาจาก Binance
  const fetchBinancePrice = (symbol: string): Promise<number> => {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${symbol.toUpperCase()}usdt@trade`);
  
      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        const price = parseFloat(data.p); // ดึงราคา
        resolve(price); // ส่งราคากลับ
        ws.close(); // ปิด WebSocket เมื่อได้รับราคาแล้ว
      };
  
      ws.onerror = (error) => {
        reject(`WebSocket Error: ${error}`);
      };
    });
  };
  
  // ฟังก์ชันที่ใช้ fetch เพื่อดึงราคาจาก Yahoo (สำหรับ Stock)
  const fetchYahooPrice = async (symbol: string): Promise<number> => {
    try {
      const response = await fetch(`/api/yahoo?symbol=${encodeURIComponent(symbol)}`);
  
      if (!response.ok) {
        throw new Error("Failed to fetch price from Yahoo");
      }
  
      const data = await response.json();
      return parseFloat(data.price); // แปลงข้อมูลราคาจาก JSON เป็นตัวเลข
    } catch (error) {
      console.error("Error fetching Yahoo price:", error);
      return 0; // ส่งกลับ 0 หากเกิดข้อผิดพลาด
    }
  };
  