// hooks/usePortfolio.ts
import { useEffect, useState } from "react";

export interface PortfolioItem {
  symbol: string;
  category: string;
  quantity: number;
  icon?: string;
}

export const usePortfolio = (userId: string | null) => {
  const [portfolio, setPortfolio] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPortfolio = async () => {
      if (!userId) return;

      try {
        const res = await fetch(`/api/portfolio?userId=${userId}`);
        
        if (!res.ok) {
          throw new Error('Error fetching portfolio');
        }

        const data = await res.json();  // แปลงเป็น JSON
        setPortfolio(data);  // ตั้งค่า portfolio
      } catch (error) {
        console.error("Error loading portfolio", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolio();
  }, [userId]);

  return { portfolio, loading };
};
