"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import Image from "next/image";
import { PortfolioItem } from "@/hooks/usePortfolio";
import { StockName } from "@/data/Stock";
import { CryptoName } from "@/data/Crypto";
import { getAssetPrice } from "@/utils/getAssetPrice"; // นำเข้า getAssetPrice

const AllAssetMeta = [...StockName, ...CryptoName];

interface AssetRowProps {
  title: string;
  items: PortfolioItem[];
}

export const AssetRow = ({ title, items }: AssetRowProps) => {
  const [assetPrices, setAssetPrices] = useState<{ [key: string]: number }>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPrices = async () => {
      const priceData: { [key: string]: number } = {};

      // ใช้ getAssetPrice เพื่อดึงราคาทุกตัว
      await Promise.all(
        items.map(async (item) => {
          const price = await getAssetPrice(item.symbol, item.category);
          priceData[item.symbol] = price;
        })
      );

      setAssetPrices(priceData); // ตั้งค่าราคาใน state
      setLoading(false); // เมื่อโหลดเสร็จแล้วหยุดการโหลด
    };

    fetchPrices();
  }, [items]);

  if (loading) {
    return <p>Loading prices...</p>; // ถ้ายังไม่โหลดเสร็จแสดงข้อความนี้
  }

  return (
    <>
      <p className="font-bold text-xl mt-6 mb-2">{title}</p>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {items.map((item) => {
          const meta = AllAssetMeta.find(
            (m) => m.tradingViewSymbol === item.symbol
          );

          const price = assetPrices[item.symbol] || 0;
          const totalValue = price * item.quantity;

          return (
            <Card
              key={item.symbol}
              className="flex justify-between items-center h-20 p-4 rounded-2xl text-black shadow-sm border border-gray-200 hover:shadow-md hover:bg-gray-100 transition-all bg-white dark:bg-zinc-900 dark:text-white"
            >
              <div className="flex items-center gap-3">
                <Image
                  src={meta?.icon || "/fallback-icon.svg"}
                  alt={meta?.name || item.symbol}
                  width={36}
                  height={36}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "/fallback-icon.svg";
                  }}
                />
                <div>
                  <p className="font-semibold">{meta?.name || item.symbol}</p>
                  <p className="text-sm text-gray-500">{item.category}</p>
                </div>
              </div>
              <div className="text-right font-bold text-lg text-gray-700 dark:text-white">
                {item.quantity.toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
                <p className="text-sm text-gray-500">at ${price}</p>
                <p className="text-lg font-bold text-green-600">
                  Total Value: ${totalValue.toFixed(2)}
                </p>
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
};
