export default function home() {
    return(
      <div>
        Home
      </div>
    )
  
  }